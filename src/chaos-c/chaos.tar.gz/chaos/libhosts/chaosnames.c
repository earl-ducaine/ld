#include <stdio.h>

main()
{
	chaosnames(stdout);
	exit(0);
}
